SLOBS: THE COMPLETE BROADCAST ANTHOLOGY
=======================================
HOW TO RUN
1. Unzip this folder anywhere. Keep all eight .html files together.
2. Double-click index.html (Chrome, Edge or Firefox recommended).
3. You need an internet connection: the games load Three.js (cdnjs) and the
   three.js post-processing add-ons (jsDelivr). If the add-ons cannot load, the
   games fall back to a built-in effects pipeline automatically.
   For fully offline play, download three.min.js (r128) and the files under
   three@0.128.0/examples/js/postprocessing and /shaders, save them here and
   point the <script src="..."> tags at them.

CHAPTERS
index.html    Master launcher, lore terminal, how-to-play/bestiary, Ultimate Custom Night
SLOBS_1.html  SLOBS Chapter 1: Signal Lost (2004)
SLOBS_2.html  SLOBS Chapter 2: Sub-Level Oceanic Broadcast Station (1989)
SLOBS_3.html  SLOBS Chapter 3: Satellite Low-Orbit Broadcast Station (2029)
SLOBS_4.html  SLOBS Chapter 4: Subterranean Line-Of-Sight Bunker Station (1974)
SLOBS_5.html  SLOBS Chapter 5: Station Lonely (2045)
SLOBS_6.html  SLOBS Chapter 6: Shortwave Lighthouse (1953)  <- required to finish the game
SLOBS_0.html  CH-00 OMEGA: The Architect, the final boss level (unlocks after Night 5 of all six chapters)

NOTES
- Progress is stored in your browser (localStorage, key SLOBS_ANTHOLOGY_PROGRESS).
- Open all files from the same location so they share one save.
- If the launcher shows "Tampered save detected", your save was edited or corrupted and was reset.
